package com.medicare.project.dao;

import java.util.List;

import com.medicare.project.beans.Product;


public interface ProductDao {

	List<Product> listAllPrd();

	int addProduct(Product product);

	List<Product> delProduct(int pid);

	List<Product> editProduct(int pid, Product product);

	List<Product> toggleProduct(int pid);

	List<Product> toggleProductSecond(int pid);

	List Antibiotic();

	List Analgesics();

	List Antipyretics();

}
