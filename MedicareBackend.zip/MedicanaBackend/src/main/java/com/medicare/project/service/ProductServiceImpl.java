package com.medicare.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.project.beans.Product;
import com.medicare.project.dao.LoginDao;
import com.medicare.project.dao.ProductDao;

@Service("pservice")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao dao;
	
	
	public ProductDao getDao() {
		return dao;
	}

	public void setDao(ProductDao dao) {
		this.dao = dao;
	}

   //admin
	
	@Override
	public int addProduct(Product product) {
		return dao.addProduct(product);
		
	}
	
	@Override
	public List<Product> editProduct(int pid, Product product) {
		return dao.editProduct(pid,product);
	}

	
	@Override
	public List<Product> delProduct(int pid) {
		return dao.delProduct(pid);
	}
	
	
	@Override
	public List<Product> listAllPrd() {
		return dao.listAllPrd();
	}

	

	@Override
	public List<Product> toggleProduct(int pid) {
		return dao.toggleProduct(pid);
	}

	@Override
	public List<Product> toggleProductSecond(int pid) {
		return dao.toggleProductSecond(pid);
	}

	//categories
	
	@Override
	public List Antibiotic() {
		return dao.Antibiotic();
	}

	@Override
	public List Analgesics() {
		return dao.Analgesics();
	}

	@Override
	public List Antipyretics() {
		return dao.Antipyretics();
	}

}
