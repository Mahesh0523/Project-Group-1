package com.medicare.project.dao;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.medicare.project.beans.Login;
import com.medicare.project.beans.Product;

@Repository
public class LoginDaoImpl implements LoginDao {

	
	@PersistenceContext
	private EntityManager em;
	
	
	@Transactional

	public int Register(Login login) {
		// TODO Auto-generated method stub
		em.persist(login);
		return login.getId();
	}
	
	
	@Transactional
	public Login LoginUser(String email, String password) {
		try {
		String jpql = "select a from Login a where email=:email and a.password=:pwd";
		TypedQuery<Login> query = em.createQuery(jpql, Login.class);
		query.setParameter("email", email);
		query.setParameter("pwd", password);
		Login login = query.getSingleResult();
		System.out.println("yes ");
		return login;
		}catch (Exception e) {
			return null;
		}
	}

	
	@Transactional
	@Override
	public List<Login> getUser() {
		// TODO Auto-generated method stub
		String sql="Select t from Login t";
		Query qry=em.createQuery(sql);
		List<Login> userList=qry.getResultList();
		System.out.println(userList);
		return userList;
	}


    @Transactional
	@Override
	public List<Login> getUserProfile(int id) {
		Query qry = em.createQuery("select l from Login l where l.id=:id");
		qry.setParameter("id", id);
		List<Login> login = qry.getResultList();
		return login;
	}
		


	@Transactional
	@Override
	public void UpdateProfile(int Id,Login login) {
		Login l = em.find(Login.class, Id);
		l.setName(login.getName());
		l.setPassword(login.getPassword());
		em.merge(l);
		String sql1="Select t from Login t";
		Query qry1=em.createQuery(sql1);
		List ProductList=qry1.getResultList();
	}


}
