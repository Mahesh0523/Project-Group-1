package com.medicare.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.project.beans.Login;
import com.medicare.project.dao.LoginDao;

@Service("loginService")
public class LoginServiceImpl implements LoginService{
	
	@Autowired
    LoginDao dao;
	
	

    @Autowired
    public LoginServiceImpl(LoginDao dao) {
        this.dao = dao;
    }
	
	
	public LoginDao getDao() {
		return dao;
	}

	public void setDao(LoginDao dao) {
		this.dao = dao;
	}

	@Override
	public int Register(Login login) {
		return dao.Register(login);
	}

	@Override
	public List<Login> getUser() {
		return dao.getUser();
	}

	

	@Override
	public List<Login> getUserProfile(int id) {
		return dao.getUserProfile(id);
	}



	@Override
	public void UpdateProfile(int Id,Login login) {
		 dao.UpdateProfile(Id,login);
	}

	@Override
	public Login LoginUser(String email, String password) {
		return dao.LoginUser(email, password);
	}


	
	
	
	

}
