package com.medicare.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.project.beans.Cart;
import com.medicare.project.beans.Product;
import com.medicare.project.dao.CartDao;
import com.medicare.project.dao.ProductDao;

@Service("cservice")
public class CartServiceImpl implements CartService{

	@Autowired
	CartDao dao;
	
	
	public CartDao getDao() {
		return dao;
	}

	public void setDao(CartDao dao) {
		this.dao = dao;
	}
	
	@Override
	public List listAllPrdinCart() {
		return dao.listAllPrdinCart();
	}

	@Override
	public List cartlistbyloginsid(int id) {
		return dao.cartlistbyloginsid(id);
	}

	@Override
	public int addToCart(Cart cart) {
		// TODO Auto-generated method stub
		return dao.addToCart(cart);
	}

	@Override
	public List sumofproduct(int id) {
		return dao.sumofproduct(id);
	}

	

	@Override
	public List bookedProducts(int id) {
		return dao.bookedProducts(id);
	}

	@Override
	public List makebooking(int id) {
		return dao.makebooking(id);
	}



	@Override
	public List delProductfromCart(int pid) {
		return dao.delProductfromCart(pid);
	}


	@Override
	public List search(String name) {
		return dao.search(name);
	}
	
	

	

}
