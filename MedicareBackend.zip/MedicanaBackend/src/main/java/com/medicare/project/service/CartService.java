package com.medicare.project.service;

import java.util.List;

import com.medicare.project.beans.Cart;
import com.medicare.project.beans.Product;

public interface CartService {

	List listAllPrdinCart();

	List cartlistbyloginsid(int id);

	int addToCart(Cart cart);

	List sumofproduct(int id);
	

	List bookedProducts(int id);

	List makebooking(int id);


	List delProductfromCart(int pid);



	List search(String name);


	

	

}
