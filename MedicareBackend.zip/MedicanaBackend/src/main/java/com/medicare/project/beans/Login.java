package com.medicare.project.beans;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="Registrations")
public class Login {
	
	@Id
	//@GeneratedValue
//	@SequenceGenerator(name="logins_seq",sequenceName="logins_seq",allocationSize=1 )

	
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="login_id_seq")
	@SequenceGenerator(name="login_id_seq",sequenceName="login_id_seq",allocationSize=1)
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	
	
	@Column(name="email")
	private String email;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name="password")
	private String password;
	

//	@Column(name="contact")
//	private long contact;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	


//	public long getContact() {
//		return contact;
//	}
//
//	public void setContact(long contact) {
//		this.contact = contact;
//	}
//


	public Login(int id, String name, String password) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		
	}


	

	@Override
	public String toString() {
		return "Login [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + "]";
	}

	public Login() {
		super();
	}
	
	
	
}
