package com.medicare.project.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.project.beans.Cart;
import com.medicare.project.service.CartService;

@SpringBootTest
class AssgnApplicationTests {

	
	@Autowired
	CartService cs;
	
		@Test
		@DisplayName("GET Cart details")
		public void getallcartTest(){

		    List<Cart> as = cs.listAllPrdinCart();
		 double rs =as.size();
		 assertTrue(rs==2);

		
	}

}
