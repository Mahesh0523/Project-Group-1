package com.medicare.project.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.project.beans.Cart;
import com.medicare.project.beans.Login;
import com.medicare.project.service.CartService;
import com.medicare.project.service.CartServiceImpl;
import com.medicare.project.service.LoginService;

@SpringBootTest
class Customer {

	
	
	@Autowired
	LoginService loginService;
	
	@Test
	void contextLoads() {
	}
	
//	
	@Test
	@DisplayName("SigUp with valid details")
	public void signUpTest(){
		Login login = new Login();
		login.setName("Arun");
		login.setPassword("123123");
		login.setEmail("arun@gmail.com");
		
		loginService.Register(login);
	}
	
	@Test
    @DisplayName("SignIn with valid details")
    public void signInTest() {
        int id = 7;
        List<Login> rs = loginService.getUserProfile(id);
        int listSize = rs.size();
        assertTrue(listSize > 0);
    }
	
	
	@Test
    @DisplayName("profile Update")
    public void profileupdate() {
		Login login =new Login();
		login.setName("Tharun");
		login.setPassword("Abcd");
		loginService.UpdateProfile(1, login);
	}
	
}
